package fetchdata;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.TreeMap;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
//import org.springframework.web.servlet.HttpServletBean;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import org.apache.commons.lang3.time.DateUtils;

public class FetchDataAPI2{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) throws IOException {
		String[] largeCap = {"TCS", "VEDL","M&M","META","MSFT","AMZN","GOOG","ABB"};
		String[] midCap = {"IDEA","PFC","OIL","L&TFH","M&MFIN"};
		String[] smallCap = {"BDL","CCL","GLS","ITI","NH","SCI","STAR"};

		try{  
    		Class.forName("com.mysql.cj.jdbc.Driver");  
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stock_recommend","root","root");  
    		Statement stmt=con.createStatement();  
    		ResultSet rs=stmt.executeQuery("select * from largecap");  
    		api_call(rs);
    		con.close(); 
    	}
		catch(Exception e){ System.out.println(e);}
	}
	
	public static void api_call(ResultSet companylist)
	{
		double average = 0,sum=0,difference=0;
		TreeMap<Double, String> t = new TreeMap<Double, String>(Collections.reverseOrder()); 
		int count =0;
		try 
		{
			while(companylist.next())
			{
				try {
			        URL url = new URL("https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol="+companylist.getString(2)+"&apikey=XSWG1AHTZAUE1K3D");
			        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			        conn.setRequestMethod("GET");
			        conn.connect();

			        //Getting the response code
			        int responsecode = conn.getResponseCode();

			        if (responsecode != 200) {
			            throw new RuntimeException("HttpResponseCode: " + responsecode);
			        } else {

			            String inline = "";
			            Scanner scanner = new Scanner(url.openStream());

			            //Write all the JSON data into a string using a scanner
			            while (scanner.hasNext()) {
			                inline += scanner.nextLine();
			            }

			            //Close the scanner
			            scanner.close();

			            //Using the JSON simple library parse the string into a json object
			            JSONParser parse = new JSONParser();
			            JSONObject data_obj = (JSONObject) parse.parse(inline);

			            //Get the required object from the above created object
			            
			            JSONObject obj = (JSONObject) data_obj.get("Meta Data");
//			            if(obj !=null)
			            //Get the required data using its key
//			            {
			            	System.out.println(obj.get("2. Symbol"));
			            	JSONObject obj1 = (JSONObject) data_obj.get("Time Series (Daily)");
			            	
			            	for(int a=1 ; a<15 ;a++)
			            	{
			            		int j=a;
				            	
			            		Date date1 = DateUtils.addDays(new Date(), -j);
			                	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			                	JSONObject new_obj = (JSONObject) obj1.get(sdf.format(date1));
			                	if(new_obj != null)
			                	{
			                		count++;
			                		sum=sum + Double.valueOf((String) new_obj.get("4. close"));
			                	}
			                }
			            	average=sum/count;
			            	System.out.println("Average "+average);
			            	Date yesterday = DateUtils.addDays(new Date(), -1);
			            	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			            	JSONObject previous = (JSONObject) obj1.get(sdf.format(yesterday));
			            	difference = average-Double.valueOf((String) previous.get("4. close"));
			            	System.out.println("Previous day closing price "+ previous.get("4. close"));
			            	System.out.println("difference is "+difference);
			            	t.put(difference,(String) obj.get("2. Symbol"));
//			            }
			        }
				}
				catch(Exception e){
					System.out.println("Exception "+e);
				}
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		System.out.println(t);
		JSONObject json = new JSONObject();
//		json.put("stock", t.values());
		
	    json.putAll(t);
	    System.out.printf( "JSON: %s", json.toString() );
	    try (FileWriter file = new FileWriter("./stocksname.json")) {

            file.write(json.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
		//System.out.println(t);
	}
}