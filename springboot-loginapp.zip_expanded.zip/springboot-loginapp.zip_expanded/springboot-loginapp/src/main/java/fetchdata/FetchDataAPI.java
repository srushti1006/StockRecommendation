//package fetchdata;
//import java.io.IOException;
//import java.math.BigDecimal;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.List;
//import java.util.Map;
//import com.java.techie.yahoo.stock.api.dto.StockDTO;
//import yahoofinance.Stock;
//import yahoofinance.YahooFinance;
//import yahoofinance.histquotes.HistoricalQuote;
//import yahoofinance.histquotes.Interval;
//
//public class FetchDataAPI 
//{
//	//getting single stock details
//	
//	public StockDTO getStock(String stockName) throws IOException {
//		StockDTO dto=null;
//		Stock stock= YahooFinance.get(stockName);
//		dto=new StockDTO(stock.getName(),stock.getQuote().getPrice(),stock.getQuote().getChange(),stock.getCurrency(),stock.getQuote().getBid());
//		return dto;
//	}
//	//multiple stock names
//	public Map<String,Stock> getStock(String[] stockNames) throws IOException {
//		Map<String,Stock> stock=YahooFinance.get(stockNames);
//		return stock;
//	}
//	
//	//for historical quotes
//	public void getHistory(String stockName) throws IOException{
//		Stock stock=YahooFinance.get(stockName);
//		List<HistoricalQuote> history=stock.getHistory();
//		for(HistoricalQuote quote:history) {
//			System.out.println("========================================");
//			System.out.println("symbol : "+quote.getSymbol());
//			System.out.println("date : "+convertDate(quote.getDate()));
//			System.out.println("High Price : "+quote.getHigh());
//			System.out.println("Low Price : "+quote.getLow());
//			System.out.println("Closing Price : "+quote.getClose());
//			System.out.println("=======================================");
//			if((convertDate(quote.getDate()).compareTo("2021-10-15")>0) && (convertDate(quote.getDate()).compareTo("2021-10-25")<0)) { 
//			//String sql = "INSERT INTO Registration VALUES (100, 'Zara', 'Ali', 18)";
//	        // stmt.executeUpdate(sql);
//			}
//		}
//	}
//	//customized weekly, monthly
//	public void getHistory(String stockName,int year,String searchType) throws IOException{
//	
//		BigDecimal sum=new BigDecimal(0.0);
//		double sum1=sum.doubleValue();
//		Calendar from=Calendar.getInstance();
//		Calendar to=Calendar.getInstance();
//		from.add(Calendar.YEAR,Integer.valueOf("-"+year));
//		Stock stock=YahooFinance.get(stockName);
//		List<HistoricalQuote> history=stock.getHistory(from, to,getInterval(searchType));
//		for(HistoricalQuote quote:history) {
//			System.out.println("========================================");
//			System.out.println("symbol : "+quote.getSymbol());
//			System.out.println("date : "+convertDate(quote.getDate()));
//			System.out.println("High Price : "+quote.getHigh());
//			System.out.println("Low Price : "+quote.getLow());
//			System.out.println("Closing Price : "+quote.getClose());
//			System.out.println("=======================================");
//			if((convertDate(quote.getDate()).compareTo("2021-10-15")>0) && (convertDate(quote.getDate()).compareTo("2021-10-25")<0)) {
////				BigDecimal bd=quote.getClose(); // the value you get
////				double d = bd.doubleValue(); // The double you want
////				sum1=sum1+d;
//			
//			}
//		    
//		}
//	}
//	
//	private Interval getInterval(String searchType) {
//		
//		Interval interval=null;
//		switch(searchType.toUpperCase()) {
//		
//		case "MONTHLY":
//			interval=Interval.MONTHLY;
//			break;
//			
//		case "WEEKLY":
//			interval=Interval.WEEKLY;
//			break;
//			
//		case "DAILY":
//			interval=Interval.DAILY;
//			break;
//	}
//		return interval;
//	}
//	
//	
//	
//	private String convertDate(Calendar cal) {
//		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
//		String formatDate=format.format(cal.getTime());
//		
//	return formatDate;
//	}
//    public static void main( String[] args ) throws IOException
//    {
//    	
//    	try{  
//    		Class.forName("com.mysql.jdbc.Driver");  
//    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/citi10","root","Sakshi123");  
//    		//here sonoo is database name, root is username and password  
//    		Statement stmt=con.createStatement();  
//    		ResultSet rs=stmt.executeQuery("select * from nifty");  
//    		while(rs.next())  
//    		{
//    		System.out.println(rs.getString(3));  
//    		YahooStockAPI yahooStockAPI=new YahooStockAPI();
//    		try {
//       	    System.out.println(yahooStockAPI.getStock(rs.getString(3)));
//       	    System.out.println();
//       	   yahooStockAPI.getHistory(rs.getString(3),1,"WEEKLY");
//       	
//    		}
//    		catch(Exception e) {
//    			e.printStackTrace();
//    		}
//    		}
//    		con.close(); 
//    		}catch(Exception e){ System.out.println(e);}   
//    	
//    	
//    	
//    	
//    	
////    	
////    	YahooStockAPI yahooStockAPI=new YahooStockAPI();
////    	//System.out.println(yahooStockAPI.getStock("INTC"));
////       // System.out.println( "Hello World!" );
////    	
////    	String[] stockNames= {"GOOG","INTC","BABA","YHOO"};
////    	//System.out.println(yahooStockAPI.getStock(stockNames));
////    	//yahooStockAPI.getHistory("GOOG");
////    
////    	yahooStockAPI.getHistory("INTC",1,"weekly");
//    	    	
//    }
//}