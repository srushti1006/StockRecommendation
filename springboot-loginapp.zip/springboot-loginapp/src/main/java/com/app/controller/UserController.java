package com.app.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.app.entity.User;
import com.app.repo.UserRepo;
import com.app.service.YahooStockAPI;
import com.java.techie.yahoo.stock.api1.Stock;

@Controller
public class UserController {

	@Autowired(required=true)
	private UserRepo repo;
	YahooStockAPI yahoostock = new YahooStockAPI();
	
	@GetMapping("/")
	public String login(Model model) {
		User user=new User();
		model.addAttribute("user",user);
		return "index";
	}
	
	@PostMapping("/userLogin")
	public String loginUser(@ModelAttribute("user") User user) {
		System.out.println("In userLogin controller");
		String userId=user.getUserId();
		Optional<User> userdata=repo.findById(userId);
		if(user.getPassword().equals(userdata.get().getPassword())) {
			return "caphome";
		}
		else {
//		return "error";
			return "error";
		}
	}
	
	@RequestMapping(value={"/displaynames"},method = RequestMethod.POST)
	public String listCompany(Model model,HttpServletRequest request) throws IOException
	{
		String cap= request.getParameter("marketcap");
		System.out.println(cap);
		System.out.println("In displaynames controller");
		TreeMap<Double,String> t = yahoostock.yahoostockfetchdata(cap);
		List<Stock> stock = new ArrayList<Stock>();
		for (Map.Entry<Double, String> i : t.entrySet()) {
			Stock s = new Stock();
			s.setDifference(i.getKey());
			s.setCompany(i.getValue());
			stock.add(s);
		}
		System.out.println(t.toString());
		model.addAttribute("company",stock);
		return  "list";
	}
}