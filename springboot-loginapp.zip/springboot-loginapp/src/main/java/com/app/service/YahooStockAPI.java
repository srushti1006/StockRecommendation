package com.app.service;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import com.java.techie.yahoo.stock.api1.StockDTO;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;

public class YahooStockAPI 
{
	public TreeMap<Double,String> t=new TreeMap(Collections.reverseOrder());
	public TreeMap<Double, String> topFiveStocks=new TreeMap(Collections.reverseOrder());
	//getting single stock details
	
	public StockDTO getStock(String stockName) throws IOException {
		StockDTO dto=null;
		Stock stock= YahooFinance.get(stockName);
		dto=new StockDTO(stock.getName(),stock.getQuote().getPrice(),stock.getQuote().getChange(),stock.getCurrency(),stock.getQuote().getBid());
		return dto;
	}
	//multiple stock names
	public Map<String,Stock> getStock(String[] stockNames) throws IOException {
		Map<String,Stock> stock=YahooFinance.get(stockNames);
		return stock;
	}
	
	//for historical quotes
	public void getHistory(String stockName) throws IOException{
		Stock stock=YahooFinance.get(stockName);
		List<HistoricalQuote> history=stock.getHistory();
		for(HistoricalQuote quote:history) {
			System.out.println("========================================");
			System.out.println("symbol : "+quote.getSymbol());
			System.out.println("date : "+convertDate(quote.getDate()));
			System.out.println("High Price : "+quote.getHigh());
			System.out.println("Low Price : "+quote.getLow());
			System.out.println("Closing Price : "+quote.getClose());
			System.out.println("=======================================");
		}
		
	}

	//customized weekly, monthly
	public BigDecimal getHistory(String stockName,int year,String searchType) throws IOException{
	
		
		BigDecimal sum=new BigDecimal(0.0);
		double sum1=sum.doubleValue();
		
		Calendar from=Calendar.getInstance();
		Calendar to=Calendar.getInstance();
		from.add(Calendar.YEAR,Integer.valueOf("-"+year));
		Stock stock=YahooFinance.get(stockName);
		List<HistoricalQuote> history=stock.getHistory(from, to,getInterval(searchType));
		int i=0;
		int count=history.size();
		BigDecimal prevClosingPrice=new BigDecimal(0.0);
		int temp=0;
		temp=count-14;
		String sym="";
		for(HistoricalQuote quote:history) {
			String symbol=quote.getSymbol();
			sym=symbol;
			String date=convertDate(quote.getDate());
			BigDecimal highPrice=quote.getHigh();
			BigDecimal lowPrice=quote.getLow();
			BigDecimal closingPrice=quote.getClose();
			if(i==count-1) {
				 prevClosingPrice=closingPrice;
				 System.out.println("Previous Day Closing Date ="+date);
			}
			if(i>=temp) {
				System.out.println("=======================================");
				
				System.out.println("Symbol="+symbol);
				System.out.println("Closing Price="+closingPrice);
				System.out.println("Date="+date);
				double close=(quote.getClose()).doubleValue();
				sum1=sum1+close;
				System.out.println("========================================");
				
			}
			else {
				
			}
			i++;
		}
		//Calculate total sum
		System.out.println(sum1);
		//Calculate average
		double avg=(double)(sum1/14);
		System.out.println("Average="+avg);
		//Calculate the Difference
		double difference=avg-prevClosingPrice.doubleValue();
		System.out.println("Difference="+difference);
		t.put(difference,sym);
		return prevClosingPrice;
	}
	
	private Interval getInterval(String searchType) {
		
		Interval interval=null;
		switch(searchType.toUpperCase()) {
		
		case "MONTHLY":
			interval=Interval.MONTHLY;
			break;
			
		case "WEEKLY":
			interval=Interval.WEEKLY;
			break;
			
		case "DAILY":
			interval=Interval.DAILY;
			break;
	}
		return interval;
	}
	
	
	
	private String convertDate(Calendar cal) {
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		String formatDate=format.format(cal.getTime());
		
	return formatDate;
	}
	
	public TreeMap<Double,String> displayTreeMap() {
		int size=t.size();
		int i=0;
		for(Map.Entry<Double,String> entry:t.entrySet()) {
			double key=entry.getKey();
			String value=entry.getValue();
			if(i<5) {
				topFiveStocks.put(key,value);
			}
			System.out.println(
	                "[" + key + ", " + value + "]");
			i++;
		}
//		System.out.println(t);
		System.out.println(topFiveStocks);
		return topFiveStocks;
		}

	public TreeMap<Double,String> yahoostockfetchdata(String cap) throws IOException
    {
    	System.out.println("In API");
    	try{  
    		Class.forName("com.mysql.cj.jdbc.Driver");  
    		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/stock_recommend","root","root");  
    		//here sonoo is database name, root is username and password  
    		Statement stmt=con.createStatement();  
    		//Small Cap
    		ResultSet rs=stmt.executeQuery("select * from "+cap+" limit 7");  
    		YahooStockAPI yahooStockAPI=new YahooStockAPI();
    		while(rs.next())  
    		{
    		//System.out.println(rs.getString(3));  
    		try {
    			int count=0;
    			double sum=0.0;
       	    System.out.println(yahooStockAPI.getStock(rs.getString(3)));
       	    System.out.println();
       	 	
       	   yahooStockAPI.getHistory(rs.getString(3),14,"DAILY");
       	   //Displaying the stocks
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}
    		}
    		con.close();
    		return yahooStockAPI.displayTreeMap();
    		}catch(Exception e){ System.out.println(e);}   
    	
    	return null;
    }
}
