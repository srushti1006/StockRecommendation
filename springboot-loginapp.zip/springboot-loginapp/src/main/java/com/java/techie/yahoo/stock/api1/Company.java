package com.java.techie.yahoo.stock.api1;

import java.io.Serializable;
import java.util.Collections;
import java.util.TreeMap;

public class Company implements Serializable{
	public TreeMap<Double, String> topFiveStocks=new TreeMap(Collections.reverseOrder());
	
}
