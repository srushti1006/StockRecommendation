package com.java.techie.yahoo.stock.api1;

public class Stock {

}
