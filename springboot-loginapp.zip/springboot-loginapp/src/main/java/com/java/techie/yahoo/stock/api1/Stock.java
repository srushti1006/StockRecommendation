package com.java.techie.yahoo.stock.api1;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class Stock {
	double difference;
	String company;
	BigDecimal closingprice;
}
