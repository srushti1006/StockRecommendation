package com.java.techie.yahoo.stock.api;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.commons.lang3.time.DateUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.java.techie.yahoo.stock.api.dto.StockDto;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.HistoricalQuote;
import yahoofinance.histquotes.Interval;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 * Hello world!
 *
 */
public class YahooStockAPI {

	public StockDto getStock(String stockName) throws IOException {
		StockDto dto = null;
		Stock stock = YahooFinance.get(stockName);
		dto = new StockDto(stock.getName(), stock.getQuote().getPrice(), stock.getQuote().getChange(),
				stock.getCurrency(), stock.getQuote().getBid());
		return dto;
	}

	public Map<String, Stock> getStock(String[] stockNames) throws IOException {
		Map<String, Stock> stock = YahooFinance.get(stockNames);
		return stock;
	}

	public void getHistory(String stockName) throws IOException {

		Stock stock = YahooFinance.get(stockName);
		List<HistoricalQuote> history = stock.getHistory();
		for (HistoricalQuote quote : history) {
			System.out.println("====================================");
			System.out.println("symobol : " + quote.getSymbol());
			System.out.println("date : " + convertDate(quote.getDate()));
			System.out.println("High Price  : " + quote.getHigh());
			System.out.println("Low Price : " + quote.getLow());
			System.out.println("Closed price : " + quote.getClose());
			System.out.println("=========================================");
		}

	}

	public void getHistory(String stockName, int year, String searchType) throws IOException {
		Calendar from = Calendar.getInstance();
		Calendar to = Calendar.getInstance();
		from.add(Calendar.YEAR, Integer.valueOf("-" + year));

		Stock stock = YahooFinance.get(stockName);
		List<HistoricalQuote> history = stock.getHistory(from, to, getInterval(searchType));
		for (HistoricalQuote quote : history) {
			System.out.println("====================================");
			System.out.println("symobol : " + quote.getSymbol());
			System.out.println("date : " + convertDate(quote.getDate()));
			System.out.println("High Price  : " + quote.getHigh());
			System.out.println("Low Price : " + quote.getLow());
			System.out.println("Closed price : " + quote.getClose());
			quote.getOpen();
			System.out.println("=========================================");
		}

	}

	private String convertDate(Calendar cal) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String formatDate = format.format(cal.getTime());
		return formatDate;
	}

	private Interval getInterval(String searchType) {
		Interval interval = null;
		switch (searchType.toUpperCase()) {
		case "MONTHLY":
			interval = Interval.MONTHLY;
			break;
		case "WEEKLY":
			interval = Interval.WEEKLY;
			break;
		case "DAILY":
			interval = Interval.DAILY;
			break;

		}
		return interval;
	}

	public static void main(String[] args) throws IOException {
		
		String[] stockNames = { "GOOG", "INTC", "IBM", "ITC", "TCS"};
//		for (String string : stockNames) {
//			System.out.println(string);
//		}
		for (String string : stockNames) {
			try {

	            URL url = new URL("https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol="+string+"&apikey=XSWG1AHTZAUE1K3D");
	            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	            conn.setRequestMethod("GET");
	            conn.connect();

	            //Getting the response code
	            int responsecode = conn.getResponseCode();

	            if (responsecode != 200) {
	                throw new RuntimeException("HttpResponseCode: " + responsecode);
	            } else {

	                String inline = "";
	                Scanner scanner = new Scanner(url.openStream());

	                //Write all the JSON data into a string using a scanner
	                while (scanner.hasNext()) {
	                    inline += scanner.nextLine();
	                }

	                //Close the scanner
	                scanner.close();

	                //Using the JSON simple library parse the string into a json object
	                JSONParser parse = new JSONParser();
	                JSONObject data_obj = (JSONObject) parse.parse(inline);

	                //Get the required object from the above created object
	                
	                JSONObject obj = (JSONObject) data_obj.get("Meta Data");
	                if(obj !=null)
	                //Get the required data using its key
	                {
	                	System.out.println(obj.get("2. Symbol"));

	                	JSONObject obj1 = (JSONObject) data_obj.get("Time Series (Daily)");
	                	System.out.println(obj1);
	                //	System.out.println(obj1.get("4. close"));
	                	//String a= "2022-06-08".get("close");
	                //	String a=(String)obj1.get("4. close");
	                	//System.out.println(a);
	       
	                	for(int a=1 ; a<14 ;a++)
	                	{
	                		int j=a;
	                		Date date1 = DateUtils.addDays(new Date(), -j);
		                	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		                	System.out.println(sdf.format(date1));
		                	System.out.println(obj1.get(sdf.format(date1)));
//		                	System.out.println(obj1.size());
		                	for (int i = 0; i < obj1.size(); i++) {
		                	  JSONObject new_obj = (JSONObject) obj1.get(i);
		                	  System.out.println(new_obj);
		                	}
		                }
	                }
	            }
			}
			catch(Exception e){
				System.out.println(e);
			}
		}
	}	
}