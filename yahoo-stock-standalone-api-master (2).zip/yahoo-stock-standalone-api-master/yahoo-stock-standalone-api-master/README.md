# yahoo-stock-standalone-api
how to get statistics and historical quotes on stocks using YahooFinance API
